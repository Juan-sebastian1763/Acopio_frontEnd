import { useState, useEffect } from "react";
import { Button, Card, CardBody, CardFooter, Image, Input } from "@nextui-org/react";
import { NavLink } from "react-router-dom";
import "../assets/css/Materiales.css";
import Cookies from "universal-cookie";

function Mispedidos() {
  const [peticiones, setPeticiones] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const cookies = new Cookies();
  const usuarioId = cookies.get('id');

  useEffect(() => {
    const fetchPeticiones = async () => {
      try {
        const response = await fetch('http://localhost:3001/peticiones');
        const data = await response.json();
        const peticionesUsuario = data.filter(peticion => peticion.usuario_id === usuarioId);
        setPeticiones(peticionesUsuario);
      } catch (error) {
        console.error("Error al obtener las peticiones:", error);
      }
    };

    fetchPeticiones();
  }, [usuarioId]);

  const filteredPeticiones = peticiones.filter((item) => {
    const searchLower = searchTerm.toLowerCase().trim();
    const statusLower = item.estado.toLowerCase().trim();

    const matchesSearchTerm = 
      item.nombre_usuario.toLowerCase().includes(searchLower) || 
      item.id.toString().includes(searchTerm);

    const matchesFilterStatus = filterStatus === "" || statusLower === filterStatus;

    return matchesSearchTerm && matchesFilterStatus;
  });

  return (
    <>
      <div className="mx-auto max-w-2xl lg:text-center">
        <p className="mt-4 text-3xl font-bold tracking-tight text-green-800 sm:text-4xl">
          Mis Solicitudes
        </p>
      </div>

      <div className="flex justify-center items-center mt-4 mb-4 space-x-4">
        <Input
          clearable
          underlined
          placeholder="Buscar por nombre o ID"
          onChange={(e) => setSearchTerm(e.target.value)}
          value={searchTerm}
          className="w-1/3"
        />

        <Button
          auto
          onClick={() => setFilterStatus("pendiente")}
          className={filterStatus === "pendiente" ? "bg-yellow-500 text-white" : "bg-gray-200 text-black"}
        >
          Pendiente
        </Button>
        <Button
          auto
          onClick={() => setFilterStatus("rechazado")}
          className={filterStatus === "rechazado" ? "bg-red-500 text-white" : "bg-gray-200 text-black"}
        >
          Rechazado
        </Button>
        <Button
          auto
          onClick={() => setFilterStatus("")}
          className={filterStatus === "" ? "bg-gray-500 text-white" : "bg-gray-200 text-black"}
        >
          Todos
        </Button>
      </div>

      <div className="gap-5 grid grid-cols-2 sm:grid-cols-5 container-materiales">
        {filteredPeticiones.length > 0 ? (
          filteredPeticiones.map((item) => (
            <Card
              shadow="lg"
              key={item.id}
              isPressable
              onPress={() => console.log("item pressed")}
            >
              <CardBody className="overflow-visible p-0">
                <Image
                  isZoomed
                  shadow="sm"
                  radius="lg"
                  width="100%"
                  alt={item.nombre_usuario}
                  className="w-full object-cover h-[240px]"
                  src={item.material_img}
                />
              </CardBody>
              <CardFooter className="text-lg justify-between">
                <b className="uppercase">
                  <span className="nombre-material"></span> {item.nombre_usuario}
                </b>
                <NavLink to={`/pedidos/${item.id}`}>
                  <Button variant="shadow" className="button-ver">
                    Ver Solicitud
                  </Button>
                </NavLink>
              </CardFooter>
            </Card>
          ))
        ) : (
          <p>No se encontraron solicitudes que coincidan con los criterios de búsqueda.</p>
        )}
      </div>
    </>
  );
}

export default Mispedidos;