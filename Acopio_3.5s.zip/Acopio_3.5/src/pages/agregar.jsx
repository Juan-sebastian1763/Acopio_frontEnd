import { useState } from "react";
import { PhotoIcon } from "@heroicons/react/24/solid";
import Swal from "sweetalert2"; // Importar SweetAlert2

export default function AgregarMaterial() {
  const [formData, setFormData] = useState({
    identificador: "",
    situacion: "",
    nombre: "",
    tipo: "",
    cantidad_disponible: "",
    estado: "",
    descripcion: "",
    color: "",
    img: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData((prevData) => ({
        ...prevData,
        img: URL.createObjectURL(file),
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("http://localhost:3001/materiales", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        // Mostrar la alerta personalizada con SweetAlert2
        Swal.fire({
          title: 'Operación Realizada con Éxito',
          text: 'Material Agregado Exitosamente',
          icon: 'success',
          confirmButtonText: 'Ok',
          timer: 5000, // La alerta desaparecerá después de 5 segundos
        });

        // Limpiar los datos del formulario
        setFormData({
          identificador: "",
          situacion: "",
          nombre: "",
          tipo: "",
          cantidad_disponible: "",
          estado: "",
          descripcion: "",
          color: "",
          img: "",
        });
      } else {
        // Manejar el error
        Swal.fire({
          title: 'Error',
          text: 'Hubo un problema al agregar el material',
          icon: 'error',
          confirmButtonText: 'Intentar de nuevo',
        });
      }
    } catch (error) {
      console.error("Error de red:", error);
      // Mostrar alerta de error de red
      Swal.fire({
        title: 'Error de Red',
        text: 'No se pudo conectar con el servidor',
        icon: 'error',
        confirmButtonText: 'Reintentar',
      });
    }
  };

  return (
    <div className="flex justify-center">
      <form onSubmit={handleSubmit} className="space-y-12 w-full max-w-4xl">
        <div className="border-b border-gray-900/10 pb-12">
          <div className="text-center">
            <p className="mt-2 text-3xl font-bold tracking-tight text-green-700 sm:text-4xl">
              Agregar Nuevo Material
            </p>
            <p className="mt-1 text-sm leading-6 text-gray-600">
              Rellena los campos para agregar un nuevo material a la base de
              datos.
            </p>
          </div>

          <div className="mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">
            <div className="sm:col-span-3">
              <label
                htmlFor="identificador"
                className="block text-sm font-medium leading-6 text-gray-900"
              >
                Identificador
              </label>
              <div className="mt-2">
                <input
                  id="identificador"
                  name="identificador"
                  type="text"
                  value={formData.identificador}
                  onChange={handleInputChange}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset sm:text-sm sm:leading-6"
                  placeholder="Identificador único del material"
                />
              </div>
            </div>
            <div className="sm:col-span-3">
              <label
                htmlFor="situacion"
                className="block text-sm font-medium leading-6 text-gray-900"
              >
                Situación
              </label>
              <div className="mt-2">
                <input
                  id="situacion"
                  name="situacion"
                  type="text"
                  value={formData.situacion}
                  onChange={handleInputChange}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset sm:text-sm sm:leading-6"
                  placeholder="Situación del material"
                />
              </div>
            </div>

            <div className="sm:col-span-3">
              <label
                htmlFor="nombre"
                className="block text-sm font-medium leading-6 text-gray-900"
              >
                Nombre
              </label>
              <div className="mt-2">
                <input
                  id="nombre"
                  name="nombre"
                  type="text"
                  value={formData.nombre}
                  onChange={handleInputChange}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset sm:text-sm sm:leading-6"
                  placeholder="Nombre del material"
                />
              </div>
            </div>
            <div className="sm:col-span-3">
              <label
                htmlFor="tipo"
                className="block text-sm font-medium leading-6 text-gray-900"
              >
                Tipo
              </label>
              <div className="mt-2">
                <select
                  id="tipo"
                  name="tipo"
                  value={formData.tipo}
                  onChange={handleInputChange}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset sm:text-sm sm:leading-6"
                >
                  <option value="">Seleccione un tipo</option>
                  <option value="consumible">Consumible</option>
                  <option value="devolutivo">Devolutivo</option>
                </select>
              </div>
            </div>

            <div className="sm:col-span-3">
              <label
                htmlFor="cantidad_disponible"
                className="block text-sm font-medium leading-6 text-gray-900"
              >
                Cantidad Disponible
              </label>
              <div className="mt-2">
                <input
                  id="cantidad_disponible"
                  name="cantidad_disponible"
                  type="number"
                  value={formData.cantidad_disponible}
                  onChange={handleInputChange}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset sm:text-sm sm:leading-6"
                  placeholder="Cantidad disponible"
                />
              </div>
            </div>
            <div className="sm:col-span-3">
              <label
                htmlFor="estado"
                className="block text-sm font-medium leading-6 text-gray-900"
              >
                Estado
              </label>
              <div className="mt-2">
                <select
                  id="estado"
                  name="estado"
                  value={formData.estado}
                  onChange={handleInputChange}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset sm:text-sm sm:leading-6"
                >
                  <option value="">Seleccione un estado</option>
                  <option value="nuevo">Nuevo</option>
                  <option value="usado">Usado</option>
                  <option value="deteriorado">Deteriorado</option>
                </select>
              </div>
            </div>

            <div className="col-span-full">
              <label
                htmlFor="descripcion"
                className="block text-sm font-medium leading-6 text-gray-900"
              >
                Descripción
              </label>
              <div className="mt-2">
                <textarea
                  id="descripcion"
                  name="descripcion"
                  value={formData.descripcion}
                  onChange={handleInputChange}
                  rows={3}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset sm:text-sm sm:leading-6"
                  placeholder="Descripción del material"
                />
              </div>
            </div>
            <div className="sm:col-span-3">
              <label
                htmlFor="color"
                className="block text-sm font-medium leading-6 text-gray-900"
              >
                Color (Opcional)
              </label>
              <div className="mt-2">
                <input
                  id="color"
                  name="color"
                  type="text"
                  value={formData.color}
                  onChange={handleInputChange}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset sm:text-sm sm:leading-6"
                  placeholder="Color del material (Opcional)"
                />
              </div>
            </div>

            <div className="col-span-full">
              <div className="mt-2 flex items-center gap-x-3">
                {formData.img && (
                  <img
                    src={formData.img}
                    alt="Preview"
                    className="h-32 w-32 rounded-lg"
                  />
                )}
                <button
                  type="button"
                  className="rounded-md bg-white text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 px-4 py-2"
                >
                  <PhotoIcon
                    className="h-6 w-6 text-gray-600"
                    aria-hidden="true"
                  />
                  Subir Imagen
                  <input
                    type="file"
                    name="img"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 flex items-center justify-end gap-x-6">
          <button
            type="submit"
            className="rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-green-500"
          >
            Guardar Material
          </button>
        </div>
      </form>
    </div>
  );
}
