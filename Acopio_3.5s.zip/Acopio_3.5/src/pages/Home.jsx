import React from "react";
import NavbarComponent from "../components/NavbarComponent";
import Inicio from "../components/Inicio";

export function Home() {
  return (
    <>
    {/* Pagina de Inicio */}
    {/* Ruta:   "/"   */}
      <Inicio />
    </>
  );
}
