import { useState, useEffect } from "react";
import { Button, Card, CardBody, CardFooter, Image } from "@nextui-org/react";
import { NavLink } from "react-router-dom";
import "../assets/css/Materiales.css";

function Pedidos() {
  const [peticiones, setPeticiones] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filtro, setFiltro] = useState("todos");

  useEffect(() => {
    const fetchPeticiones = async () => {
      try {
        const response = await fetch('http://localhost:3001/peticiones');
        const data = await response.json();
        // Filtrar las peticiones con estado "Pendiente"
        const peticionesPendientes = data.filter(peticion => peticion.estado === "Pendiente");
        setPeticiones(peticionesPendientes);
      } catch (error) {
        console.error("Error al obtener las peticiones:", error);
      }
    };

    fetchPeticiones();
  }, []);

  // Función para manejar la búsqueda
  const handleSearch = (event) => {
    setSearchQuery(event.target.value.toLowerCase());
  };

  // Filtrar por tipo (todos, devolutivo, consumible)
  const handleFilter = (tipo) => {
    setFiltro(tipo);
  };

  // Filtrar las peticiones según el tipo y la búsqueda
  const peticionesFiltradas = peticiones.filter((item) => {
    const tipoValido = filtro === "todos" || item.tipo_material === filtro;
    const nombreValido = item.nombre_usuario ? item.nombre_usuario.toLowerCase().includes(searchQuery) : false;
    return tipoValido && nombreValido;
  });

  return (
    <>
      <div className="mx-auto max-w-2xl lg:text-center">
        <p className="mt-4 text-3xl font-bold tracking-tight text-green-700 sm:text-4xl">
          Solicitudes
        </p>
        {/* Barra de búsqueda y botones de filtro alineados */}
        <div className="search-and-filter">
          <div className="search-bar">
            <input
              type="text"
              placeholder="Buscar por nombre de usuario"
              value={searchQuery}
              onChange={handleSearch}
              className="search-input"
            />
          </div>

          {/* Botones de filtro */}
          <div className="filter-buttons">
            <Button 
              onClick={() => handleFilter("todos")}
              className={filtro === "todos" ? "active" : ""}
            >
              Todos
            </Button>
            <Button 
              onClick={() => handleFilter("devolutivo")}
              className={filtro === "devolutivo" ? "active" : ""}
            >
              Devolutivo
            </Button>
            <Button 
              onClick={() => handleFilter("consumible")}
              className={filtro === "consumible" ? "active" : ""}
            >
              Consumible
            </Button>
          </div>
        </div>
      </div>

      <div className="gap-5 grid grid-cols-2 sm:grid-cols-5 container-materiales">
        {peticionesFiltradas.length > 0 ? (
          peticionesFiltradas.map((item) => {
            // Validar los valores de las propiedades
            const nombreUsuario = item.nombre_usuario || "Usuario desconocido";
            const imagenMaterial = item.material_img || "ruta/a/imagen_default.png"; // Imagen por defecto si no hay imagen

            return (
              <Card
                shadow="lg"
                key={item.id}
                isPressable
                onPress={() => console.log("item pressed")}
              >
                <CardBody className="overflow-visible p-0">
                  <Image
                    isZoomed
                    shadow="sm"
                    radius="lg"
                    width="100%"
                    alt={nombreUsuario}
                    className="w-full object-cover h-[240px]"
                    src={imagenMaterial}  // Usar la imagen del material
                  />
                </CardBody>
                <CardFooter className="text-lg justify-between">
                  <b className="uppercase">
                    <span className="nombre-material"></span> {nombreUsuario}
                  </b>
                  <NavLink to={`/pedidos/${item.id}`}>
                    <Button variant="shadow" className="button-ver">
                      Ver Solicitud
                    </Button>
                  </NavLink>
                </CardFooter>
              </Card>
            );
          })
        ) : (
          <p>No hay solicitudes pendientes.</p>
        )}
      </div>
    </>
  );
}

export default Pedidos;
