import { useState } from 'react';
import Cookies from 'universal-cookie';
import CryptoJS from 'crypto-js'; // Importa crypto-js para MD5

const Perfil = () => {
  const cookies = new Cookies();
  const [isEditing, setIsEditing] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState(''); // Nuevo estado para confirmar contraseña
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const correo = cookies.get("correo");
  const nombre = cookies.get("nombre");
  const telefono = cookies.get("telefono");
  const userId = cookies.get("id");

  const handleEditClick = () => {
    setIsEditing(true);
  };

  const handleSaveClick = async () => {
    if (newPassword.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres.');
      setSuccessMessage('');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('Las contraseñas no coinciden.');
      setSuccessMessage('');
      return;
    }

    // Encriptar la nueva contraseña con MD5
    const contraseñaEncriptada = CryptoJS.MD5(newPassword).toString();

    try {
      const response = await fetch(`http://localhost:3001/usuarios/${userId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ contraseña: contraseñaEncriptada }),
      });

      if (response.ok) {
        setError('');
        setSuccessMessage('Contraseña actualizada correctamente');
        setNewPassword('');
        setConfirmPassword(''); // Limpiar el campo de confirmar contraseña
        setIsEditing(false);
      } else {
        setError('Error al actualizar la contraseña.');
        setSuccessMessage('');
      }
    } catch (error) {
      console.error("Error de red:", error);
      setError('Error de red. Intenta de nuevo.');
      setSuccessMessage('');
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-gray-100 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-center text-gray-800">Información básica</h2>
      <div className="mt-4 bg-white p-4 rounded-lg shadow">
        <div className="flex justify-between mb-4">
          <span className="font-semibold text-gray-600">Nombre:</span>
          <span className="text-gray-800">{nombre}</span>
        </div>
        <div className="flex justify-between mb-4">
          <span className="font-semibold text-gray-600">Correo:</span>
          <span className="text-gray-800">{correo}</span>
        </div>
        <div className="flex justify-between mb-4">
          <span className="font-semibold text-gray-600">Teléfono:</span>
          <span className="text-gray-800">{telefono}</span>
        </div>
        <div className="flex justify-between mb-4">
          <span className="font-semibold text-gray-600">Contraseña:</span>
          {isEditing ? (
            <>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="border border-gray-300 rounded px-2 py-1 w-2/3"
                placeholder="Nueva contraseña"
              />
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="border border-gray-300 rounded px-2 py-1 w-2/3"
                placeholder="Confirmar contraseña"
              />
            </>
          ) : (
            <span className="text-gray-800">********</span>
          )}
        </div>
        {error && <p className="text-red-500 text-sm text-center">{error}</p>}
        {successMessage && <p className="text-green-500 text-sm text-center">{successMessage}</p>}
        <div className="text-center">
          {isEditing ? (
            <button
              className="mt-4 bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
              onClick={handleSaveClick}
            >
              Guardar
            </button>
          ) : (
            <button
              className="mt-4 bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
              onClick={handleEditClick}
            >
              Editar Información
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Perfil;
