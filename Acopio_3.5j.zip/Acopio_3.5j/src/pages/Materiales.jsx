import { useState, useEffect } from "react";
import { Button, Card, CardBody, CardFooter, Image, Input } from "@nextui-org/react";
import { NavLink } from "react-router-dom";
import "../assets/css/Materiales.css";

function Materiales() {
  const [materiales, setMateriales] = useState([]);
  const [searchTerm, setSearchTerm] = useState(""); // Estado para la búsqueda por nombre o ID
  const [filterType, setFilterType] = useState(""); // Estado para el filtro de tipo (devolutivo o consumible)

  useEffect(() => {
    // Llama a la API para obtener los materiales desde db.json
    fetch("/src/api/db.json")
      .then((response) => response.json())
      .then((data) => setMateriales(data.materiales))
      .catch((error) => console.error("Error al cargar materiales:", error));
  }, []);

  // Filtra los materiales según el término de búsqueda (solo nombre o id) y tipo
  const filteredMateriales = materiales.filter((item) => {
    const searchLower = searchTerm.toLowerCase().trim(); // Normaliza la búsqueda
    const tipoLower = item.tipo.toLowerCase().trim(); // Normaliza el tipo

    // Verifica si el término de búsqueda coincide con nombre o id
    const matchesSearchTerm = 
      item.nombre.toLowerCase().includes(searchLower) || 
      item.id.toString().includes(searchTerm);

    // Filtra por tipo si hay un tipo seleccionado
    const matchesFilterType = filterType === "" || tipoLower === filterType;

    return matchesSearchTerm && matchesFilterType;
  });

  return (
    <>
      <div className="mx-auto max-w-2xl lg:text-center">
        <p className="mt-4 text-3xl font-bold tracking-tight text-green-800 sm:text-4xl">
          Solicitar Material
        </p>
      </div>

      {/* Barra de búsqueda y botones alineados horizontalmente */}
      <div className="flex justify-center items-center mt-4 mb-4 space-x-4">
        {/* Barra de búsqueda */}
        <Input
          clearable
          underlined
          placeholder="Buscar por nombre o ID"
          onChange={(e) => setSearchTerm(e.target.value)}
          value={searchTerm}
          className="w-1/3" // Ajusta el tamaño de la barra de búsqueda
        />

        {/* Botones de filtro para "Devolutivo" y "Consumible" */}
        <Button
          auto
          onClick={() => setFilterType("devolutivo")} // Filtrar por tipo "Devolutivo"
          className={filterType === "devolutivo" ? "bg-green-500 text-white" : "bg-gray-200 text-black"}
        >
          Devolutivo
        </Button>
        <Button
          auto
          onClick={() => setFilterType("consumible")} // Filtrar por tipo "Consumible"
          className={filterType === "consumible" ? "bg-green-500 text-white" : "bg-gray-200 text-black"}
        >
          Consumible
        </Button>
        <Button
          auto
          onClick={() => setFilterType("")} // Mostrar todos los tipos (quitar el filtro)
          className={filterType === "" ? "bg-gray-500 text-white" : "bg-gray-200 text-black"}
        >
          Todos
        </Button>
      </div>

      {/* Si no hay materiales después del filtrado, muestra el mensaje "Material no disponible" */}
      {filteredMateriales.length === 0 ? (
        <div className="text-center text-red-500 text-xl mt-4">
          Material no disponible
        </div>
      ) : (
        <div className="mt-4 gap-5 grid grid-cols-2 sm:grid-cols-5 container-materiales">
          {filteredMateriales.map((item) => (
            <Card
              shadow="lg"
              key={item.id}
              isPressable
              onPress={() => console.log("item pressed")}
            >
              <CardBody className="overflow-visible p-0">
                <Image
                  isZoomed
                  shadow="sm"
                  radius="lg"
                  width="100%"
                  alt={item.nombre}
                  className="w-full object-cover h-[240px]"
                  src={item.img}
                />
              </CardBody>
              <CardFooter className="text-lg justify-between">
                <b className="uppercase">
                  <span className="nombre-material"></span> {item.nombre}
                </b>
                <NavLink to={`/materiales/${item.id}`}>
                  <Button variant="shadow" className="button-ver">
                    Ver Material
                  </Button>
                </NavLink>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </>
  );
}

export default Materiales;
