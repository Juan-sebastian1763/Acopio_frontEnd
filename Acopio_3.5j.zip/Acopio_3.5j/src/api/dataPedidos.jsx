export const PedidoData = [
  {
    id_pedido: 1,
    id_material: 1,
    id_usu: "Jonathan",
    cantidad: 5,
    estado_solicitud: "En proceso",
    fecha: "02/07/2024",
    img: "../../src/assets/img/materiales/marcador-negro.png",
  },
  {
    id_pedido: 2,
    id_material: 3,
    id_usu: "Aley",
    cantidad: 1,
    estado_solicitud: "En proceso",
    fecha: "05/07/2024",
    img: "../../src/assets/img/materiales/borrador-tablero.png",
  },
];